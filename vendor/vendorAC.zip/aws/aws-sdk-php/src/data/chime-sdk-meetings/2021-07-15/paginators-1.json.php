<?php
// This file was auto-generated from sdk-root/src/data/chime-sdk-meetings/2021-07-15/paginators-1.json
return [ 'pagination' => [ 'ListAttendees' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
