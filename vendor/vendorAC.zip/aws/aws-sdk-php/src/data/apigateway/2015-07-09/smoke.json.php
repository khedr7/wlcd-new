<?php
// This file was auto-generated from sdk-root/src/data/apigateway/2015-07-09/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'GetDomainNames', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'CreateUsagePlanKey', 'input' => [ 'usagePlanId' => 'foo', 'keyId' => 'bar', 'keyType' => 'fixx', ], 'errorExpectedFromService' => true, ], ],];
