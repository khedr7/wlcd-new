<?php

namespace Obydul\LaraSkrill;

use Illuminate\Support\ServiceProvider;

class LaraSkrillServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
