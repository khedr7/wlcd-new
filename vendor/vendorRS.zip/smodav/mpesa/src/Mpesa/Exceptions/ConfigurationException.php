<?php

namespace SmoDav\Mpesa\Exceptions;

use Exception;

class ConfigurationException extends Exception
{
}
