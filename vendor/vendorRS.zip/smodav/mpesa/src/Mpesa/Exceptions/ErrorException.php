<?php

namespace SmoDav\Mpesa\Exceptions;

use Exception;

class ErrorException extends Exception
{
}
