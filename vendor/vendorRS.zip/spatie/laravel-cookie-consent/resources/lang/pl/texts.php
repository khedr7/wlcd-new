<?php

return [
    'message' => 'Twoje doświadczenia na tej witrynie będą lepsze dzięki cookies.',
    'agree' => 'Zezwalaj na cookie',
];
