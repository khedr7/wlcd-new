<?php

return [
    'message' => 'Tato stránka používá cookies na vylepšení vašeho uživatelského zážitku.',
    'agree' => 'Souhlasím',
];
