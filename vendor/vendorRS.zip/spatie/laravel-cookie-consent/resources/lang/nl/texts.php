<?php

return [
    'message' => 'Uw ervaring op deze site wordt verbeterd door het gebruik van cookies.',
    'agree' => 'Sta cookies toe',
];
