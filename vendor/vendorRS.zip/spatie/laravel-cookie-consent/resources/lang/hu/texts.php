<?php

return [
    'message' => 'A megfelelő élmény biztosításához sütikre van szükség.',
    'agree' => 'Sütik engedélyezése',
];
