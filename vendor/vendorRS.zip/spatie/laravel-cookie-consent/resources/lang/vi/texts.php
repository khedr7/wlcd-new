<?php

return [
    'message' => 'Trải nghiệm của bạn trên trang web này sẽ được cải thiện bằng cách cho phép Cookie.',
    'agree' => 'Cho phép Cookie',
];
