<?php

namespace Spatie\GoogleTagManager\Exceptions;

class ApiKeyNotSetException extends \Exception
{
}
