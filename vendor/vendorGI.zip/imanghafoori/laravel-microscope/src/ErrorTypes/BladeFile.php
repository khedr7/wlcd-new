<?php

namespace Imanghafoori\LaravelMicroscope\ErrorTypes;

class BladeFile
{
    use MicroEvent;
}
