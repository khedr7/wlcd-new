<?php

namespace Imanghafoori\LaravelMicroscope\ErrorTypes;

class EnvFound
{
    use MicroEvent;
}
