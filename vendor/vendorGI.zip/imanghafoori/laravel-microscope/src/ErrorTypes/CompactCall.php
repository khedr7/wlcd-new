<?php

namespace Imanghafoori\LaravelMicroscope\ErrorTypes;

class CompactCall
{
    use MicroEvent;
}
