<?php

namespace Imanghafoori\LaravelMicroscope\ErrorTypes;

class ddFound
{
    use MicroEvent;
}
