# gRPC PHP Client Library

This repository contains only PHP files to support Composer installation.

This repository is a mirror of [gRPC](https://github.com/grpc/grpc). Any support
requests, bug reports, or development contributions should be directed to
that project.

To install gRPC for PHP, please see https://github.com/grpc/grpc/tree/master/src/php
